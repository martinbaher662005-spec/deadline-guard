require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const APP_URL = (process.env.APP_URL || `http://localhost:${PORT}`).replace(/\/$/, "");
const JWT_SECRET = process.env.JWT_SECRET || "";
const PAYMOB_BASE = "https://accept.paymob.com";

if (process.env.NODE_ENV === "production" && JWT_SECRET.length < 32) {
  throw new Error("Set a strong JWT_SECRET (at least 32 characters) in production.");
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cookieParser());
app.use(express.json({ limit: "1mb" }));

const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "deadline-guard.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  plan TEXT NOT NULL DEFAULT 'free',
  subscription_status TEXT NOT NULL DEFAULT 'inactive',
  subscription_expires_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS deadlines (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Other',
  due_date TEXT NOT NULL,
  remind_days INTEGER NOT NULL DEFAULT 3,
  provider TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  done INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  plan TEXT NOT NULL,
  amount_cents INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'EGP',
  paymob_order_id TEXT UNIQUE,
  paymob_intention_id TEXT,
  transaction_id TEXT UNIQUE,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const PLANS = {
  starter: { name: "Starter", price: 50, limit: 20 },
  pro: { name: "Pro", price: 150, limit: Infinity },
  business: { name: "Business", price: 300, limit: Infinity }
};

function safeUser(row) {
  if (!row) return null;
  return {
    id: row.id, name: row.name, email: row.email, plan: row.plan,
    subscriptionStatus: row.subscription_status,
    subscriptionExpiresAt: row.subscription_expires_at
  };
}
function makeToken(user) {
  return jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: "7d" });
}
function auth(req, res, next) {
  const token = req.cookies.dg_token || (req.headers.authorization || "").replace(/^Bearer /, "");
  if (!token) return res.status(401).json({ error: "Please sign in." });
  try {
    req.auth = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "Session expired. Please sign in again." });
  }
}
function currentUser(req) {
  return db.prepare("SELECT * FROM users WHERE id = ?").get(req.auth.id);
}
function activePlan(user) {
  if (!user) return "free";
  if (user.plan !== "free" && user.subscription_expires_at &&
      new Date(user.subscription_expires_at).getTime() > Date.now() &&
      user.subscription_status === "active") return user.plan;
  return "free";
}
function setSession(res, user) {
  res.cookie("dg_token", makeToken(user), {
    httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production",
    maxAge: 7 * 24 * 60 * 60 * 1000
  });
}
function paymobConfigured() {
  return Boolean(process.env.PAYMOB_SECRET_KEY && process.env.PAYMOB_PUBLIC_KEY &&
    process.env.PAYMOB_INTEGRATION_ID && process.env.PAYMOB_HMAC_SECRET);
}
function paymobHmacValid(obj, received) {
  const fields = [
    obj.amount_cents, obj.created_at, obj.currency, obj.error_occured,
    obj.has_parent_transaction, obj.id, obj.integration_id, obj.is_3d_secure,
    obj.is_auth, obj.is_capture, obj.is_refunded, obj.is_standalone_payment,
    obj.is_voided, obj.order && obj.order.id, obj.owner, obj.pending,
    obj.source_data && obj.source_data.pan, obj.source_data && obj.source_data.sub_type,
    obj.source_data && obj.source_data.type, obj.success
  ];
  if (fields.some(v => v === undefined || v === null)) return false;
  const joined = fields.map(v => typeof v === "boolean" ? String(v).toLowerCase() : String(v)).join("");
  const expected = crypto.createHmac("sha512", process.env.PAYMOB_HMAC_SECRET).update(joined).digest("hex");
  const a = Buffer.from(expected, "utf8"), b = Buffer.from(String(received || ""), "utf8");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

app.use("/api", rateLimit({ windowMs: 15 * 60 * 1000, limit: 250, standardHeaders: true, legacyHeaders: false }));

app.post("/api/auth/register", rateLimit({ windowMs: 60 * 60 * 1000, limit: 10 }), async (req, res) => {
  const name = String(req.body.name || "").trim().slice(0, 80);
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 8) {
    return res.status(400).json({ error: "Enter a name, valid email and password (at least 8 characters)." });
  }
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)").run(name, email, hash);
    const user = db.prepare("SELECT * FROM users WHERE id=?").get(result.lastInsertRowid);
    setSession(res, user);
    res.json({ user: safeUser(user) });
  } catch (e) {
    if (String(e).includes("UNIQUE")) return res.status(409).json({ error: "This email is already registered." });
    res.status(500).json({ error: "Could not create account." });
  }
});

app.post("/api/auth/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 15 }), async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user || !(await bcrypt.compare(String(req.body.password || ""), user.password_hash))) {
    return res.status(401).json({ error: "Email or password is incorrect." });
  }
  setSession(res, user);
  res.json({ user: safeUser(user) });
});
app.post("/api/auth/logout", (req, res) => {
  res.clearCookie("dg_token", { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" });
  res.json({ ok: true });
});
app.get("/api/me", auth, (req, res) => {
  const user = currentUser(req);
  if (!user) return res.status(401).json({ error: "Account not found." });
  res.json({ user: { ...safeUser(user), plan: activePlan(user) }, plans: PLANS, paymobConfigured: paymobConfigured() });
});

app.get("/api/deadlines", auth, (req, res) => {
  const rows = db.prepare("SELECT * FROM deadlines WHERE user_id=? ORDER BY due_date ASC, id DESC").all(req.auth.id);
  res.json({ deadlines: rows });
});
app.post("/api/deadlines", auth, (req, res) => {
  const user = currentUser(req), plan = activePlan(user);
  const count = db.prepare("SELECT COUNT(*) n FROM deadlines WHERE user_id=? AND done=0").get(user.id).n;
  const limit = plan === "free" ? 5 : PLANS[plan].limit;
  if (count >= limit) return res.status(402).json({ error: `Your ${plan} plan limit is ${limit} active deadlines. Upgrade to add more.` });
  const title = String(req.body.title || "").trim().slice(0, 120);
  const dueDate = String(req.body.due_date || "");
  if (!title || !/^\d{4}-\d{2}-\d{2}$/.test(dueDate)) return res.status(400).json({ error: "Title and valid due date are required." });
  const result = db.prepare(`INSERT INTO deadlines(user_id,title,category,due_date,remind_days,provider,notes)
    VALUES(?,?,?,?,?,?,?)`).run(user.id, title, String(req.body.category || "Other").slice(0,40),
      dueDate, Math.max(0, Math.min(365, Number(req.body.remind_days ?? 3))),
      String(req.body.provider || "").slice(0,100), String(req.body.notes || "").slice(0,1000));
  res.json({ deadline: db.prepare("SELECT * FROM deadlines WHERE id=?").get(result.lastInsertRowid) });
});
app.put("/api/deadlines/:id", auth, (req, res) => {
  const existing = db.prepare("SELECT * FROM deadlines WHERE id=? AND user_id=?").get(req.params.id, req.auth.id);
  if (!existing) return res.status(404).json({ error: "Deadline not found." });
  const title = String(req.body.title ?? existing.title).trim().slice(0,120);
  const dueDate = String(req.body.due_date ?? existing.due_date);
  if (!title || !/^\d{4}-\d{2}-\d{2}$/.test(dueDate)) return res.status(400).json({ error: "Invalid title or date." });
  db.prepare(`UPDATE deadlines SET title=?,category=?,due_date=?,remind_days=?,provider=?,notes=?,done=? WHERE id=? AND user_id=?`)
    .run(title, String(req.body.category ?? existing.category).slice(0,40), dueDate,
      Math.max(0,Math.min(365,Number(req.body.remind_days ?? existing.remind_days))),
      String(req.body.provider ?? existing.provider).slice(0,100),
      String(req.body.notes ?? existing.notes).slice(0,1000),
      req.body.done === undefined ? existing.done : (req.body.done ? 1 : 0), existing.id, req.auth.id);
  res.json({ deadline: db.prepare("SELECT * FROM deadlines WHERE id=?").get(existing.id) });
});
app.delete("/api/deadlines/:id", auth, (req, res) => {
  const result = db.prepare("DELETE FROM deadlines WHERE id=? AND user_id=?").run(req.params.id, req.auth.id);
  if (!result.changes) return res.status(404).json({ error: "Deadline not found." });
  res.json({ ok: true });
});

app.post("/api/checkout", auth, async (req, res) => {
  const planKey = String(req.body.plan || "");
  const plan = PLANS[planKey];
  if (!plan) return res.status(400).json({ error: "Unknown plan." });
  if (!paymobConfigured()) return res.status(503).json({ error: "Paymob is not connected yet. Add your Paymob test credentials to .env first." });
  if (process.env.PAYMOB_LIVE_MODE !== "true" && !process.env.PAYMOB_INTEGRATION_ID) {
    return res.status(503).json({ error: "Paymob integration is not configured." });
  }
  const user = currentUser(req);
  const reference = `DG-${user.id}-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`;
  const amountCents = plan.price * 100;
  const paymentInsert = db.prepare("INSERT INTO payments(user_id,plan,amount_cents,status) VALUES(?,?,?,'pending')").run(user.id, planKey, amountCents);
  try {
    const response = await fetch(`${PAYMOB_BASE}/v1/intention/`, {
      method: "POST",
      headers: { "Authorization": `Token ${process.env.PAYMOB_SECRET_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        amount: amountCents, currency: "EGP",
        payment_methods: [Number(process.env.PAYMOB_INTEGRATION_ID)],
        items: [{ name: `Deadline Guard ${plan.name} monthly subscription`, amount: amountCents, description: `${plan.name} plan - one month`, quantity: 1 }],
        billing_data: {
          apartment: "NA", first_name: user.name.split(" ")[0] || "Customer",
          last_name: user.name.split(" ").slice(1).join(" ") || "Customer",
          street: "NA", building: "NA", phone_number: process.env.DEFAULT_PHONE || "+200000000000",
          city: "Alexandria", country: "EG", email: user.email, floor: "NA", state: "Alexandria"
        },
        special_reference: reference,
        expiration: 3600,
        notification_url: `${APP_URL}/api/paymob/webhook`,
        redirection_url: `${APP_URL}/payment-result`
      })
    });
    const data = await response.json();
    if (!response.ok || !data.client_secret) {
      console.error("Paymob intention error:", data);
      db.prepare("UPDATE payments SET status='failed' WHERE id=?").run(paymentInsert.lastInsertRowid);
      return res.status(502).json({ error: "Paymob could not create checkout. Check your Secret Key and Integration ID in the merchant dashboard." });
    }
    db.prepare("UPDATE payments SET paymob_order_id=?,paymob_intention_id=? WHERE id=?")
      .run(String(data.intention_order_id || ""), String(data.id || ""), paymentInsert.lastInsertRowid);
    const checkoutUrl = `${PAYMOB_BASE}/unifiedcheckout/?publicKey=${encodeURIComponent(process.env.PAYMOB_PUBLIC_KEY)}&clientSecret=${encodeURIComponent(data.client_secret)}`;
    res.json({ checkoutUrl });
  } catch (e) {
    console.error("Paymob request failed:", e.message);
    db.prepare("UPDATE payments SET status='failed' WHERE id=?").run(paymentInsert.lastInsertRowid);
    res.status(502).json({ error: "Could not reach Paymob. Try again later." });
  }
});

// Only this verified server-to-server callback activates a plan. Never activate from the browser redirect.
app.post("/api/paymob/webhook", async (req, res) => {
  const obj = req.body && req.body.obj;
  const receivedHmac = req.query.hmac;
  if (!obj || !paymobHmacValid(obj, receivedHmac)) {
    console.warn("Rejected Paymob callback: invalid HMAC.");
    return res.status(200).json({ received: true, verified: false });
  }
  const orderId = String(obj.order && obj.order.id || "");
  const payment = db.prepare("SELECT * FROM payments WHERE paymob_order_id=?").get(orderId);
  if (!payment) return res.status(200).json({ received: true, matched: false });
  const user = db.prepare("SELECT * FROM users WHERE id=?").get(payment.user_id);
  const paid = obj.success === true && obj.pending === false && obj.is_refunded !== true &&
    Number(obj.amount_cents) === payment.amount_cents && String(obj.currency) === "EGP";
  if (!paid) {
    db.prepare("UPDATE payments SET status='failed',transaction_id=? WHERE id=?")
      .run(String(obj.id || ""), payment.id);
    return res.status(200).json({ received: true, paid: false });
  }
  const existing = db.prepare("SELECT id FROM payments WHERE transaction_id=?").get(String(obj.id));
  if (existing) return res.status(200).json({ received: true, duplicate: true });
  const expiryBase = user.subscription_expires_at && new Date(user.subscription_expires_at) > new Date()
    ? new Date(user.subscription_expires_at) : new Date();
  expiryBase.setMonth(expiryBase.getMonth() + 1);
  const tx = db.transaction(() => {
    db.prepare("UPDATE payments SET status='paid',transaction_id=? WHERE id=?").run(String(obj.id), payment.id);
    db.prepare("UPDATE users SET plan=?,subscription_status='active',subscription_expires_at=? WHERE id=?")
      .run(payment.plan, expiryBase.toISOString(), payment.user_id);
  });
  tx();
  res.status(200).json({ received: true, paid: true });
});

app.get("/payment-result", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "payment-result.html"));
});
app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Deadline Guard running at ${APP_URL}`));
