# Deadline Guard — deployable starter

A full-stack starter for the Deadline Guard MVP. It includes account registration/login, a database-backed deadline manager, three monthly plan prices, Paymob Unified Checkout initiation, and a server-side HMAC-verified Paymob transaction webhook.

## Plans configured

- Starter: 50 EGP/month (20 active deadlines)
- Pro: 150 EGP/month (unlimited active deadlines)
- Business: 300 EGP/month (unlimited active deadlines; team workspace is marked coming soon)

The free account is limited to 5 active deadlines.

## Important payment behavior

This build currently charges a **single monthly payment when the customer checks out** and extends the plan by one month after a verified payment. Customers must renew manually each month.

Paymob advertises recurring subscriptions/tokenization, but recurring billing must be enabled for your merchant account and implemented against the subscription APIs for your account. Do not describe this build as automatic card renewal yet. See Paymob's subscription product and developer portal:
- https://paymob.eg/en/subscriptions
- https://developers.paymob.com/

The payment return page does not activate a plan. Only a valid server-to-server transaction callback with matching HMAC, order ID, amount, currency and success state can activate it.

## Run locally

Requirements: Node.js 20+

```bash
npm install
cp .env.example .env
```

Set `JWT_SECRET` to a random secret of at least 32 characters. Then:

```bash
npm start
```

Open http://localhost:3000

The app can be tested without Paymob: registration, login and deadline management work locally. Payment checkout will show a clear message until Paymob credentials are added.

## Connect Paymob (test mode first)

In your Paymob merchant dashboard, obtain the credentials for an Egypt online integration:
- Secret Key
- Public Key
- Integration ID for the payment method you want to accept
- HMAC Secret

Add them to `.env`:
- `PAYMOB_SECRET_KEY`
- `PAYMOB_PUBLIC_KEY`
- `PAYMOB_INTEGRATION_ID`
- `PAYMOB_HMAC_SECRET`

Keep `PAYMOB_LIVE_MODE=false` while testing. Set `APP_URL` to the public HTTPS URL of your deployed app. Configure the Paymob transaction processed callback to:
`https://YOUR-DOMAIN/api/paymob/webhook`

The checkout endpoint creates an intention using Paymob's current Unified Checkout Intention API and redirects the customer to the hosted checkout. The callback is verified using HMAC-SHA512.

Before live launch:
1. Test successful, failed, duplicate, refunded and mismatched-amount callbacks.
2. Confirm the callback is reaching the deployed HTTPS endpoint.
3. Confirm the Paymob integration ID and secret belong to the same test/live mode.
4. Ask Paymob to enable recurring subscriptions if you want automatic renewals.
5. Set `PAYMOB_LIVE_MODE=true` only after Paymob approves your live account and you replace all test credentials with live credentials.
6. Deploy with HTTPS, backups, monitoring and a production database plan.

## Deployment

Deploy the Node app to a host that supports persistent storage for SQLite (for example a small VPS). The `data/` folder must persist between restarts and deployments. For multiple app instances or serverless hosting, replace SQLite with PostgreSQL before launch.

## Scope / not yet included

- No automatic email, SMS, WhatsApp or push reminders.
- No real document file uploads or OCR/date extraction.
- No team seats/shared business workspaces yet.
- No admin dashboard, invoices, refunds UI, password reset or email verification.
- No automatic recurring card charges until Paymob recurring/subscription APIs are enabled and added.
- No domain, hosting account, merchant account or live credentials are included.

This is a working starter project, not a published website or a guarantee of production readiness. A security review and live-payment testing are required before accepting real customer payments.
